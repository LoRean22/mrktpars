const container = document.getElementById("page-container")
const buttons = document.querySelectorAll(".bottom-nav button")

function loadPage(page) {
  fetch(`pages/${page}.html`)
    .then(r => r.text())
    .then(html => container.innerHTML = html)

  buttons.forEach(b => b.classList.remove("active"))
  document.querySelector(`[data-page="${page}"]`).classList.add("active")
}

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    loadPage(btn.dataset.page)
  })
})

loadPage("info")
