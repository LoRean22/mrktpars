const tg = window.Telegram.WebApp
tg.expand()
